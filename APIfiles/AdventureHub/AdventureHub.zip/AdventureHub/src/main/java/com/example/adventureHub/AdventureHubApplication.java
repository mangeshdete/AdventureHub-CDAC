package com.example.adventureHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdventureHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdventureHubApplication.class, args);
	}

}
