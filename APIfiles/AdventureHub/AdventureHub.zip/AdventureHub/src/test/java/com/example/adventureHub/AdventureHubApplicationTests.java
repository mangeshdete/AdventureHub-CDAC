package com.example.adventureHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdventureHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
